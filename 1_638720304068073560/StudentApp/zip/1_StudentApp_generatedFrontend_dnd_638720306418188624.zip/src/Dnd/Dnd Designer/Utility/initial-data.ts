import { COMPONENT, ROW, COLUMN } from "./constants";

const initialData = {
  layout: [],
  components: {}
};

export default initialData;

