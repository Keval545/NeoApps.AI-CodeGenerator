import { DropDownListComponent } from '@syncfusion/ej2-react-dropdowns';
import { AxiosResponse } from 'axios';
import { useEffect, useState } from 'react';
import './style.css'

export const DropDownList: React.FC = () => {
    return (
        <div>hello</div>
    )
}
